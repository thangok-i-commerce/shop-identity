package thangok.icommerce.cartsession;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CartSessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
