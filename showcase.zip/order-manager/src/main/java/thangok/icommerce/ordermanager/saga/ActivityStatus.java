package thangok.icommerce.ordermanager.saga;

public enum ActivityStatus {
    PENDING,
    SUCCESS,
    FAIL
}
