package thangok.icommerce.ordermanager.enumerable;

public enum OrderStatus {
    FULL_FILLED,
    ABORTED
}
